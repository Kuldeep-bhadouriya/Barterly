import TrackingCard from "@/components/tracking-card"

export default function Page() {
  return <TrackingCard />
}

