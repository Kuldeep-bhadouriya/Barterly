"use client"

import ActionSearchBar from "../components/kokonutui/action-search-bar"

export default function SyntheticV0PageForDeployment() {
  return <ActionSearchBar />
}